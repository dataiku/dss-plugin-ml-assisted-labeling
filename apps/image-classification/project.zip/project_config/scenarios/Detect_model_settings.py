import dataikuapi
import dataiku
client = dataiku.api_client()

project = client.get_project(dataiku.Project().project_key)
mltask = project.get_ml_task("SZl3VWlm","83Vgs6lX")

mltask.guess(reguess_level="TARGET_REGUESS")