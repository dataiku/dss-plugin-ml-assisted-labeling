import dataikuapi
import dataiku
client = dataiku.api_client()

project = client.get_project(dataiku.Project().project_key)
mltask = project.get_ml_task("pYCrBroE","Uurvkg3v")

mltask.guess(reguess_level="FULL_REGUESS")