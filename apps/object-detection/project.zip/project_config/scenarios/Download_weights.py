import dataiku, dataikuapi
c = dataiku.api_client()
pk = dataiku.Project().project_key
p = dataikuapi.dss.project.DSSProject(c, pk)

download_macros = [m for m in p.list_macros() if 'object-detection-download-models' in m['runnableType']]
if len(download_macros) == 0:
    raise Exception("Couldn't find download weights macros, make sure that object detection plugin is properly installed")
runnable_type = download_macros[0]['runnableType']
m = dataikuapi.dss.macro.DSSMacro(c,pk,runnable_type)
m.run({"model": "retinanet_coco", "folder_name": "coco-pretrained"})