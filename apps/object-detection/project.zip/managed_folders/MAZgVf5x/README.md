Please use the object-detection plugin macro to download retinanet weights in this folder.
